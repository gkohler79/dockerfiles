<?php

$magicWords = [];

$magicWords['en'] = [
	'getdisplaytitle' => [ 0, 'getdisplaytitle' ]
];
