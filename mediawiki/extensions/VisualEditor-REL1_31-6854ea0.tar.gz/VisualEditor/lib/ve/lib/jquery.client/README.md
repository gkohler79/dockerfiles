[![Build Status](https://travis-ci.org/wikimedia/jquery-client.svg?branch=master)](https://travis-ci.org/wikimedia/jquery-client) [![npm](https://img.shields.io/npm/v/jquery-client.svg?style=flat)](https://www.npmjs.com/package/jquery-client)

jQuery Client
=================

jQuery Client is a jQuery plugin for user-agent detection.
